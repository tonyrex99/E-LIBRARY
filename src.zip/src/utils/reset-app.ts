function resetApp() {
  return window.location.reload();
}

export default resetApp;
