import HotKeys from './HotKeys';

export default HotKeys;
