// TODO: needs a better typing for Recoil
type AtomEffectParams = {
  // eslint-disable-next-line
  [key: string]: any;
};

export type { AtomEffectParams };
