import { Outlet } from 'react-router-dom';
function AdminBookManagement() {
  return <Outlet />;
}

export default AdminBookManagement;
