import Typography from '@mui/material/Typography';

import Meta from '@/components/Meta';
import { Outlet } from 'react-router-dom';
import { Link } from 'react-router-dom';
function BookTransaction() {
  return <Outlet />;
}

export default BookTransaction;
