import AdminHome from './AdminHome';

export default AdminHome;
