import Notification from '@/pages/User/Notification';
function AdminNotifications() {
  return <Notification />;
}

export default AdminNotifications;
