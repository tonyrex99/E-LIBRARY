import BorrowedBook from './BorrowedBook';

export default BorrowedBook;
