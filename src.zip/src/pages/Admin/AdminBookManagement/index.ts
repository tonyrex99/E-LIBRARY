import AdminBookManagement from './AdminBookManagement';

export default AdminBookManagement;
