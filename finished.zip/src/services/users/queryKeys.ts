const QUERY_KEYS = {
  USERSDATA: 'Users Data',
} as const;

export default QUERY_KEYS;
