import isMobile from 'is-mobile';

export default isMobile();
