import Welcome from './Welcome';

export default Welcome;
