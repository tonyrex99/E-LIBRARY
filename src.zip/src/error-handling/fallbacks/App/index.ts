import AppErrorBoundaryFallback from './App';

export default AppErrorBoundaryFallback;
