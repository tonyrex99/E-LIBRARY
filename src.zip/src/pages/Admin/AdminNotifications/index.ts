import AdminNotifications from './AdminNotifications';

export default AdminNotifications;
