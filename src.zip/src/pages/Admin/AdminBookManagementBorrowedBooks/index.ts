import AdminBorrowedBooks from './AdminBorrowedBooks';

export default AdminBorrowedBooks;
