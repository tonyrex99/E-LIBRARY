import Book from './Book';

export default Book;
