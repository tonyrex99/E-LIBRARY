type Actions = {
  toggle: () => void;
  close: () => void;
  open: () => void;
};

export type { Actions };
