export const LOGIN = 'authentication/login';
export const REGISTER = 'authentication/sign-up';
